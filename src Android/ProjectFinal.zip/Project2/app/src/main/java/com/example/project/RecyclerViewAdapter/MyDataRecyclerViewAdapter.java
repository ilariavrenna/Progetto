package com.example.project.RecyclerViewAdapter;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.project.databinding.FragmentDataBinding;

import java.util.List;


public class MyDataRecyclerViewAdapter extends RecyclerView.Adapter<MyDataRecyclerViewAdapter.ViewHolder> {

    private final List<String> mValues;

    public MyDataRecyclerViewAdapter(List<String> items) {
        mValues = items;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

    return new ViewHolder(FragmentDataBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));

    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mItem = mValues.get(position);
        holder.data.setText(mValues.get(position));
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final TextView data;
        public String mItem;

    public ViewHolder(FragmentDataBinding binding) {
      super(binding.getRoot());
      data = binding.content;
    }

        @Override
        public String toString() {
            return super.toString() + " '" + data.getText() + "'";
        }
    }
}