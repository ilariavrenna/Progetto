package com.example.project.Fragment;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import com.example.project.Activity.MainActivity;
import com.example.project.Utils.DeviceBluetooth;
import com.example.project.RecyclerViewAdapter.MyDeviceBluetoothRecyclerViewAdapter;
import com.example.project.R;

import java.util.ArrayList;

/**
 * A fragment representing a list of Items.
 */
public class DeviceBluetoothFragment extends Fragment {

    private static final String ARG_COLUMN_COUNT = "column-count";
    private int mColumnCount = 1;
    private boolean flag=false;
    private RecyclerView recyclerView;
    private ArrayList<DeviceBluetooth> list = new ArrayList<>();
    private DeviceBluetooth elementClicked= null; //Elemento precedentemente cliccato
    private BluetoothAdapter bluetoothAdapter;
    private MyDeviceBluetoothRecyclerViewAdapter adapter = new MyDeviceBluetoothRecyclerViewAdapter(list, new MyDeviceBluetoothRecyclerViewAdapter.ItemClickListner() {@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        public void onItemClick(DeviceBluetooth device, int indexPosition) {

            //realizzare la connessione bluetooth

            MainActivity activity = (MainActivity) getActivity();
            activity.connetti(device, indexPosition);


        }
    });
    private Context context;



    public DeviceBluetoothFragment() {
    }


    public static DeviceBluetoothFragment newInstance(int columnCount) {
        DeviceBluetoothFragment fragment = new DeviceBluetoothFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_item_list, container, false);

        // Set the adapter
        if (view instanceof RecyclerView) {
            Context context = view.getContext();
            recyclerView = (RecyclerView) view;
            if (mColumnCount <= 1) {
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
            } else {
                recyclerView.setLayoutManager(new GridLayoutManager(context, mColumnCount));
            }

            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.JELLY_BEAN_MR1)
                bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            else {
                Activity activity = getActivity();
                BluetoothManager bluetoothManager = (BluetoothManager) activity.getSystemService(Context.BLUETOOTH_SERVICE);
                bluetoothAdapter = bluetoothManager.getAdapter();
            }

                for (BluetoothDevice d : bluetoothAdapter.getBondedDevices()) {
                    list.add(new DeviceBluetooth(d));
                }

                //aggiunge al layout della lista il separatore tra un elemento e l'altro
                recyclerView.addItemDecoration(new DividerItemDecoration(getContext(), LinearLayoutManager.VERTICAL));
                recyclerView.setAdapter(adapter);

            }
            return view;
        }


        public boolean aggiornaLista(DeviceBluetooth device){
            int index = list.size();
            if (device!=null && !list.contains(device)) {
                list.add(index, device);
                adapter.notifyItemInserted(index);
                return true;
            }
            return false;
        }

        public boolean cancellaLista() {
            list.clear();
            adapter.notifyDataSetChanged();
            return true;
        }



        @Override
        public void onAttach (@NonNull Context context){
            //Chiamata quando il frammento è associato alla sua activity
            super.onAttach(context);
            this.context = context;
        }

        @Override
        public void onResume () {
            super.onResume();

        }

        @Override
        public void onPause () {
            super.onPause();
        }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }


    public boolean aggiornaItem(DeviceBluetooth device, int index){
        if(device.getDevice()!=null && index>=0) {
            list.set(index, device);
            adapter.notifyItemChanged(index);
            return true;
        }
        return false;
    }




}
