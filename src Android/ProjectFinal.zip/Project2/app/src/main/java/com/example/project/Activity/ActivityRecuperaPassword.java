package com.example.project.Activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.project.R;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.SecureRandom;

public class ActivityRecuperaPassword extends AppCompatActivity {

    private AlertDialog.Builder builder;
    private static final String URL= "http://XXX.XXX.X.XX/vsc_android/send_email.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recupera_password);
        builder = new AlertDialog.Builder(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //Recuperiamo le view per gestire gli eventi
        Button invia= (Button) findViewById(R.id.buttonInvia);
        EditText EditEmail= findViewById(R.id.editTextEmailAddress2);

        invia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email= EditEmail.getText().toString();
                if(email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    TextView text= findViewById(R.id.textViewEmail2);
                    text.setVisibility(View.VISIBLE);
                }else{
                    //Inviamo email contenente password temporanea
                    InviaEmail inviaEmail= new InviaEmail(email);
                    inviaEmail.execute();


                }

            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }



    class InviaEmail extends AsyncTask<Void, Void, String> {

        private String email, passwordReset;
        private final int LENGHT= 12;

        public InviaEmail(String email){

            this.email=email;
            this.passwordReset=generaPassword(LENGHT);

        }
        
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            /*if(s!=null && s.equals("ok")){
                builder.setMessage("Controlla nella tua posta");
                builder.setCancelable(true);
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                AlertDialog alert= builder.create();
                alert.show();
            } else*/
            if(s!=null){
                builder.setMessage(s);
                builder.setCancelable(true);
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                AlertDialog alert= builder.create();
                alert.show();
            }
        }

        @Override
        protected String doInBackground(Void... voids) {
            try{
                java.net.URL url = new URL(URL);
                HttpURLConnection connessione = (HttpURLConnection) url.openConnection();
                connessione.setRequestMethod("POST");
                connessione.setDoOutput(true);
                connessione.setDoInput(true);

                Uri.Builder builder = new Uri.Builder()
                        .appendQueryParameter("email", email )
                        .appendQueryParameter("psw_reset", passwordReset);

                String query= builder.build().getEncodedQuery();
                OutputStream os= connessione.getOutputStream();
                BufferedWriter w = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                w.write(query);
                w.flush();
                w.close();
                os.close();
                connessione.connect();
                BufferedReader br = new BufferedReader
                        (new InputStreamReader(connessione.getInputStream()));
                String risposta=br.readLine(); //leggiamo la risposta del server
                return risposta;
            } catch (Exception e) {
                return null;
            }
        }

        private String generaPassword(int len){
            StringBuilder sb= new StringBuilder(len);
            SecureRandom random= new SecureRandom();
            final String chars="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

            for(int i=0; i<len; i++){
                sb.append(chars.charAt(random.nextInt(chars.length())));
            }


            return sb.toString();

        }
    }
}