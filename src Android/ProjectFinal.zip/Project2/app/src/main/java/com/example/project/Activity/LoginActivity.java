package com.example.project.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.project.R;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class LoginActivity extends AppCompatActivity {

    private final int REQUEST_CODE= 10;
    private static final String URL= "http://XXX.XXX.X.XX/vsc_android/select_user.php";
    private AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        builder = new AlertDialog.Builder(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
         //Recuperiamo le view per poter gestire i vari eventi
         View buttonLogin = findViewById(R.id.buttonLogin);
         TextView registrati= findViewById(R.id.textViewRegistrati);
         TextView recuperaPass= findViewById(R.id.textViewPasswordDimenticata);

         buttonLogin.setOnClickListener(new View.OnClickListener(){

             @Override
             public void onClick(View view) {
                 //Recuperoiamo i dati inseriti nel campo email e nel campo password
                 EditText email = findViewById(R.id.editTextTextEmailAddress);
                 EditText password= findViewById(R.id.editTextTextPassword);

                 //Accediamo al DB per verificare se l'utente è registrato
                 LeggiDati leggiDati= new LeggiDati(email, password);
                 leggiDati.execute();
             }
         });

         registrati.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 //Avviamo l'activity che gestisce la registrazione utente
                 Intent i = new Intent(getApplicationContext(), RegisterActivity.class);
                 startActivityForResult(i, REQUEST_CODE);
             }
         });

         recuperaPass.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 //Avviamo l'activity che gestice il recupero delle credenziali
                 Intent i= new Intent(getApplicationContext(), ActivityRecuperaPassword.class);
                 startActivity(i);
             }
         });



    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    private void mainActivty(String id, String psw){
        Intent i= new Intent(getApplicationContext(), MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); //cancella tutto lo stack delle actiivity quindi se premiamo il tasto back questa activity non sarà raggiungibile
        //Passiamo i paramentri id e password dell'utente alla mainActivity
        i.putExtra("ID_UTENTE", id);
        i.putExtra("PSW_UTENTE", psw);
        startActivity(i);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==REQUEST_CODE && resultCode==RESULT_OK){
            //Registrazione effettuata con successo. Puoi eseguire l'accesso.

            builder.setMessage(R.string.registrazioneSuccesso);
            builder.setCancelable(true);
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {

                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
            
        }else if(requestCode==REQUEST_CODE && resultCode==RESULT_CANCELED){
            //Errore durante il processo di registazione.

            builder.setMessage(R.string.registrazioneFallita);
            builder.setCancelable(true);
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            });
            AlertDialog alert = builder.create();
            alert.show();

        }
    }

    class LeggiDati extends AsyncTask<Void, Void, String> {

        private String email, password;

        public LeggiDati(EditText email, EditText password){

            this.email=email.getText().toString();
            this.password=password.getText().toString();

        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null) {
                if (s.equals("noU")) {
                    builder.setMessage("Utente non registrato");
                    builder.setCancelable(true);
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                        }
                    });
                    AlertDialog alert = builder.create();
                    alert.show();

                } else if (s.equals("noP")) {
                    builder.setMessage("La password inserita non é corretta");
                    builder.setCancelable(true);
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                        }
                    });
                    AlertDialog alert = builder.create();
                    alert.show();

                } else if (s.equals("noE")) {
                    builder.setMessage("Errore durante il processo di identificazione. Riprovare.");
                    builder.setCancelable(true);
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                        }
                    });
                    AlertDialog alert = builder.create();
                    alert.show();

                } else {
                    //Identificazione avvenuta con successo
                    mainActivty(s, password);

                }
            }
        }

        @Override
        protected String doInBackground(Void... voids) {
            try{
                java.net.URL url = new URL(URL);
                HttpURLConnection connessione = (HttpURLConnection) url.openConnection();
                connessione.setRequestMethod("POST");
                connessione.setDoOutput(true);
                connessione.setDoInput(true);

                Uri.Builder builder = new Uri.Builder()
                        .appendQueryParameter("email", email )
                        .appendQueryParameter("password", password );

                String query= builder.build().getEncodedQuery();
                OutputStream os= connessione.getOutputStream();
                BufferedWriter w = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                w.write(query);
                w.flush();
                w.close();
                os.close();
                connessione.connect();
                BufferedReader br = new BufferedReader
                        (new InputStreamReader(connessione.getInputStream()));
                String risposta=br.readLine(); //leggiamo la risposta del server
                return risposta;
            } catch (Exception e) {
                return null;
            }
        }
    }
}