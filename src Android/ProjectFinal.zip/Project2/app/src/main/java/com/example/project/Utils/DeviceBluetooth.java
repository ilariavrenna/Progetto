package com.example.project.Utils;

import android.bluetooth.BluetoothDevice;

import androidx.annotation.Nullable;

public class DeviceBluetooth {

    private BluetoothDevice device;
    private int stato=0; //0 non connesso, 1 associazione, 2 connesso

    public DeviceBluetooth(BluetoothDevice device){
        this.device= device;
    }



    public BluetoothDevice getDevice(){
        return device;
    }

    public int getStato(){
        return stato;
    }

    public void setStato(int stato){
        this.stato=stato;
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if( obj instanceof DeviceBluetooth){
            DeviceBluetooth deviceBluetooth= (DeviceBluetooth) obj;
            return this.device.equals(deviceBluetooth.getDevice());
        }
        return false;
    }


}
