package com.example.project.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.example.project.Activity.LoginActivity;
import com.example.project.R;

public class SplashScreen extends AppCompatActivity {

    private static int DURATA_SPLASH_SCREEN=5000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash_screen);


        Animation anim= AnimationUtils.loadAnimation(getApplicationContext(), R.anim.text_animation);
        View logo= findViewById(R.id.logo);
        logo.startAnimation(anim);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i= new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(i);
                finish();
            }
        }, DURATA_SPLASH_SCREEN);
    }
}