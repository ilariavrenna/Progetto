package com.example.project.RecyclerViewAdapter;

import androidx.recyclerview.widget.RecyclerView;

import android.bluetooth.BluetoothDevice;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.project.Utils.DeviceBluetooth;
import com.example.project.R;
import com.example.project.databinding.FragmentItemBinding;

import java.util.ArrayList;
import java.util.List;


public class MyDeviceBluetoothRecyclerViewAdapter extends RecyclerView.Adapter<MyDeviceBluetoothRecyclerViewAdapter.ViewHolder> {

    private List<DeviceBluetooth> mValues;
    private ItemClickListner mItemClickListner;



    public MyDeviceBluetoothRecyclerViewAdapter(List<DeviceBluetooth> items, ItemClickListner itemClickListner) {
        mValues = items;
        this.mItemClickListner= itemClickListner;
    }

    public void setItem(List<DeviceBluetooth> list){
        if(list==null)
            list= new ArrayList<DeviceBluetooth>();
        this.mValues=list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        return new ViewHolder(FragmentItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));

    }


    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        DeviceBluetooth device= mValues.get(position);
        holder.mItem = device.getDevice();
       // holder.mIdView.setText(mValues.get(position).id);
        if(device.getDevice().getName()!=null) {
            holder.mIdView.setText(device.getDevice().getName());
            if(device.getStato()==0){
                holder.mStato.setText(R.string.stato_non_connesso);
            }else if(device.getStato()==1){
                holder.mStato.setText(R.string.stato_assocciazione);
            }else if(device.getStato()==2){
                holder.mStato.setText(R.string.stato_connesso);
            }
        }
        holder.itemView.setOnClickListener(view -> {
            mItemClickListner.onItemClick(mValues.get(position),position);
        });

    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public interface ItemClickListner{
        void onItemClick(DeviceBluetooth device, int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final TextView mIdView;
        public final TextView mStato;
        public BluetoothDevice mItem;

        public ViewHolder(FragmentItemBinding binding) {
            super(binding.getRoot());
            mIdView = binding.content;
            mStato= binding.statoConnessione;
        }

        @Override
        public String toString() {
            return super.toString();// + " '" + mContentView.getText() + "'";
        }
    }

    public DeviceBluetooth get(int index){
        return mValues.get(index);
    }
}