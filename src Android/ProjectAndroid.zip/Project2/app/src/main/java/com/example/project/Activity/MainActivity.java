package com.example.project.Activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.Utils.BluetoothService;
import com.example.project.Utils.Costanti;
import com.example.project.Fragment.DataFragment;
import com.example.project.Utils.DeviceBluetooth;
import com.example.project.Fragment.DeviceBluetoothFragment;
import com.example.project.R;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private final String SEND_MESSAGE_EROGA= "a";
    private final String SEND_MESSAGE_BAR= "b";
    private final int FULL=5;
    private final int EMPTY=20;
    private AlertDialog.Builder builder;
    private static final String URL1= "http://192.168.1.13/vsc_android/select_list.php"; // Recupero lista erogazioni
    private static final String URL2= "http://192.168.1.13/vsc_android/update_lista.php"; // Aggiorno la lista di erogazioni
    private static final String URL3= "http://192.168.1.13/vsc_android/update_password.php"; // Aggiorno la password


    private final int REQUEST_ENABLE_BT=10;
    private  BluetoothAdapter bluetoothAdapter;
    private DeviceBluetoothFragment fragmentDeviceBluetooth;
    private DataFragment fragmentData;
    private BluetoothService bluetoothService;
    private View fragmentListBluetooth,fragmentButton, buttonEroga, fragmentListData, fragmentModifcaPsw;
    private TextView textPercetuale;
    private ProgressBar progressBar;
    private DeviceBluetooth currentDevice =null, lastDevice= null;
    private int currentIndexPosition, lastIndexPosition;
    private String idUtente, passwordUtente;
    private String passwordUtenteNew= null;
    private ArrayList<String> lista= new ArrayList<>();
    private boolean listDataChange= false;
    private final int MAX_SIZE= 10;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(Build.VERSION.SDK_INT<= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }else {
            BluetoothManager bluetoothManager= (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            bluetoothAdapter = bluetoothManager.getAdapter();
        }
        if(!bluetoothAdapter.isEnabled()){
            Intent intent= new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent, REQUEST_ENABLE_BT);

        }
        //Recuperiamo le view di cui non tutte saranno visibili
        fragmentListBluetooth=findViewById(R.id.list_fragment_bluetooth);
        fragmentButton=findViewById(R.id.fragment_button);
        buttonEroga= findViewById(R.id.ErogaButton);
        fragmentListData= findViewById(R.id.list_fragment_data);
        textPercetuale= findViewById(R.id.Percentuale);
        progressBar= findViewById(R.id.progressBar);
        fragmentModifcaPsw= findViewById(R.id.PassModifica);

        fragmentModifcaPsw.setVisibility(View.INVISIBLE);

        fragmentDeviceBluetooth =(DeviceBluetoothFragment) getSupportFragmentManager().findFragmentById(R.id.list_fragment_bluetooth);
        fragmentData = (DataFragment) getSupportFragmentManager().findFragmentById(R.id.list_fragment_data);

        //Recupero id e password dell'utente
        Intent i= getIntent();
        idUtente= i.getStringExtra("ID_UTENTE");
        passwordUtente= i.getStringExtra("PSW_UTENTE");

        File file=new File(getApplicationContext().getFilesDir()+"/"+"petsfood.txt");

        if(file.exists()){
            //Recupero lista erogazioni dal file salvato nell'internal storage dedicata all'app
            byte[] bytes= new byte[(int) file.length()];

            try {
                FileInputStream fis = new FileInputStream(file);
                fis.read(bytes);
                lista= getDataList(new String(bytes));
                file.delete();
            } catch (IOException e){
                e.printStackTrace();
            }
        }else{
            //recupero la lista delle precendeti erogazioni dal DB
            ChiamataDB chiamataDB= new ChiamataDB();
            chiamataDB.execute(1);
        }


        bluetoothService= new BluetoothService(bluetoothAdapter, handler); //gestisce la comunicazione bluetooth. Handel viene utilizzato per inviare e ricevere messaggi
        builder = new AlertDialog.Builder(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(listDataChange){
            ChiamataDB chiamataDB= new ChiamataDB();
            chiamataDB.execute(0); //salviamo i dati nel DB
        }
        if(bluetoothService!= null){
            bluetoothService.stop();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater= getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);

        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();

        Button erogaButton= (Button) findViewById(R.id.ErogaButton);
        erogaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(bluetoothService.getStato()== bluetoothService.STATE_CONNECTED) {
                    //Recupero data e ora
                    String data= new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
                    if(!listDataChange)
                         listDataChange= true;
                    if(lista.size()>=MAX_SIZE){
                        lista.remove(MAX_SIZE-1);
                    }
                    lista.add(0,data);
                    //Invio messaggio ad aurduino per avviare l'erogazione
                    inviaMessaggio(true);



                }else{

                    builder.setMessage(R.string.dispositivoNonConnesso);
                    builder.setCancelable(true);
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {

                        }
                    });
                    AlertDialog alert = builder.create();
                    alert.show();

                }
            }
        });

        View ricercaButton = findViewById(R.id.RicercaButton);
        ricercaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(bluetoothAdapter!=null && bluetoothAdapter.isEnabled()) {
                    if(bluetoothAdapter.isDiscovering())
                        bluetoothAdapter.cancelDiscovery();
                    fragmentDeviceBluetooth.cancellaLista();
                    bluetoothService.stop();
                    currentDevice= null;
                    lastDevice=null;
                    lastIndexPosition=-1;
                    currentIndexPosition=-1;
                    if(bluetoothAdapter.startDiscovery()){

                        IntentFilter intent = new IntentFilter();
                        intent.addAction(BluetoothDevice.ACTION_FOUND);
                        intent.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
                        //broadcastReceiver
                        registerReceiver(receiver, intent);

                    }
                }else{
                    Intent intent= new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(intent, REQUEST_ENABLE_BT);
                }

            }
        });

        View buttonModifica = findViewById(R.id.buttonModifica);
        buttonModifica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String psw= ((EditText) findViewById(R.id.passwordAttuale)).getText().toString();
                String pswNew= ((EditText) findViewById(R.id.NuovaPassword)).getText().toString();
                String pswRepeat= ((EditText) findViewById(R.id.RipetiPassword)).getText().toString();
                TextView textViewModica= findViewById(R.id.textViewModifca);

                if(psw.equals("") || pswNew.equals("") || pswRepeat.equals("")){
                    //Compila tutti i campi
                    textViewModica.setText("Compila tutti i campi");

                }else if(!psw.equals(passwordUtente)){
                    //La password inserita non è corretta
                    textViewModica.setText("La password non è corretta");

                }else if(pswNew.equals(psw)){

                    textViewModica.setText("Inserire una password diversa");
                }else if( !pswNew.equals(pswRepeat)){
                    //Le password inserite non coincidono
                    textViewModica.setText("Le password non coincidono");

                }else if(pswNew.length()<6){

                    textViewModica.setText("Password troppo corta");


                }else{
                    //Salva dati
                    passwordUtenteNew= pswNew;
                    ChiamataDB chiamataDB= new ChiamataDB();
                    chiamataDB.execute(2);
                }

            }
        });

        progressBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inviaMessaggio(false);
            }
        });


    }


    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }


    public  ArrayList<String> getDataList(String lista){
        //Converte la stringa del DB (che contiene lo storico delle erogazioni) in un ArrayList
        if(lista.equals("null"))
            return new ArrayList<String>();
        ArrayList<String> risultato= new ArrayList<String>();
        int indexI=0;
        int indexF= lista.indexOf("-");
        while(indexF>0){

            risultato.add(lista.substring(indexI, indexF));
            indexI=indexF+1;
            indexF=  lista.indexOf("-", indexF+1);
        }
        risultato.add(lista.substring(indexI));

        return risultato;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case R.id.menuRicerca:
                fragmentListBluetooth.setVisibility(View.VISIBLE);
                fragmentButton.setVisibility(View.VISIBLE);
                buttonEroga.setVisibility(View.INVISIBLE);
                fragmentListData.setVisibility(View.INVISIBLE);
                textPercetuale.setVisibility(View.INVISIBLE);
                progressBar.setVisibility(View.INVISIBLE);
                fragmentModifcaPsw.setVisibility(View.INVISIBLE);
                setTitle(R.string.name_find_connect);
                break;
            case R.id.menuPrincipale:

                fragmentListBluetooth.setVisibility(View.INVISIBLE);
                fragmentButton.setVisibility(View.INVISIBLE);
                buttonEroga.setVisibility(View.VISIBLE);
                fragmentListData.setVisibility(View.INVISIBLE);
                textPercetuale.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.VISIBLE);
                fragmentModifcaPsw.setVisibility(View.INVISIBLE);

                setTitle(R.string.app_name);
                break;
            case R.id.menuImpostazioni:
                //Modifica password
                fragmentListBluetooth.setVisibility(View.INVISIBLE);
                fragmentButton.setVisibility(View.INVISIBLE);
                buttonEroga.setVisibility(View.INVISIBLE);
                fragmentListData.setVisibility(View.INVISIBLE);
                textPercetuale.setVisibility(View.INVISIBLE);
                progressBar.setVisibility(View.INVISIBLE);
                fragmentModifcaPsw.setVisibility(View.VISIBLE);



                setTitle("Modifica password");
                break;
            case R.id.menuStorico:
                /****
                     Implementa codice....
                 *****/
                fragmentData.aggiornaLista(lista);
                fragmentListBluetooth.setVisibility(View.INVISIBLE);
                fragmentButton.setVisibility(View.INVISIBLE);
                buttonEroga.setVisibility(View.INVISIBLE);
                fragmentListData.setVisibility(View.VISIBLE);
                textPercetuale.setVisibility(View.INVISIBLE);
                progressBar.setVisibility(View.INVISIBLE);
                fragmentModifcaPsw.setVisibility(View.INVISIBLE);

                setTitle("Storico");

                break;
            case R.id.menuLogout:
                //eseguiamo il logout
                Intent i= new Intent(getApplicationContext(), LoginActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);//cancelliamo lo stack delle activity
                startActivity(i);


                break;
        }
        return true;
    }




    private void inviaMessaggio(boolean flag){
        byte[] messaggio;
        if(flag)
            messaggio= SEND_MESSAGE_EROGA.getBytes();
        else
            messaggio= SEND_MESSAGE_BAR.getBytes(); //legge il livello di carico
        bluetoothService.write(messaggio);

    }



    private String salvaDati(){
        //Convertiamo l'ArrayList in una stringa per salvarlo nel DB
        if(lista.isEmpty())
            return "null";
        String s= "";
        for(int i=0; i<lista.size()-1; i++)
            s+= lista.get(i) + "-";
        return s+lista.get(lista.size()-1);
    }



    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {

                //Se viene rilevato un nuovo dispositivo bluetooth lo aggiungiamo alla lista
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if(device.getName()!=null) {
                    fragmentDeviceBluetooth.aggiornaLista(new DeviceBluetooth(device));
                  //  mBluetoothDevice.add(device);
                }

            } else if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)){
                if(fragmentListBluetooth.getVisibility()==View.VISIBLE)
                    Toast.makeText(getApplicationContext(), R.string.toast_scansione, Toast.LENGTH_LONG).show();

            }
        }
    };


    public void connetti(DeviceBluetooth device, int indexPosition)  {


        if(currentDevice==null){ //Se è la prima volta che ci si connette ad un dispositivo corrente
            currentDevice=device;
            currentIndexPosition=indexPosition;
        }else{
            lastIndexPosition=currentIndexPosition;
            lastDevice= currentDevice;
            currentIndexPosition=indexPosition;
            currentDevice= device;
        }
        if(bluetoothAdapter.isDiscovering())
            bluetoothAdapter.cancelDiscovery();

        bluetoothService.stabilisciConnessione(device.getDevice());


    }

    private final Handler handler= new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case Costanti.MESSAGGIO_NUOVO_STATO:
                    switch (msg.arg1) {
                        case BluetoothService.STATE_CONNECTED:

                            if(currentDevice!= null && currentIndexPosition>=0) {
                                currentDevice.setStato(2);
                                fragmentDeviceBluetooth.aggiornaItem(currentDevice, currentIndexPosition);
                                inviaMessaggio(false);
                            }

                            break;
                        case BluetoothService.STATE_CONNECTING:
                            if(lastDevice!=null && lastIndexPosition>=0){
                                lastDevice.setStato(0);
                                fragmentDeviceBluetooth.aggiornaItem(lastDevice, lastIndexPosition );
                                lastDevice=null;
                                lastIndexPosition=-1;
                            }
                            if(currentDevice!=null && currentIndexPosition>=0){
                                currentDevice.setStato(1);
                                fragmentDeviceBluetooth.aggiornaItem(currentDevice, currentIndexPosition);
                            }
                            break;
                        case BluetoothService.STATE_NONE:
                            if(currentDevice!=null && currentIndexPosition>=0){
                                currentDevice.setStato(0);
                                fragmentDeviceBluetooth.aggiornaItem(currentDevice, currentIndexPosition);
                                currentDevice=null;
                                currentIndexPosition=-1;
                            }
                            break;
                    }
                    break;
                case Costanti.MESSAGGIO_RICEVUTO:
                    String readMessage = (String) msg.obj; //rivevo la distanza
                    TextView b= findViewById(R.id.Percentuale);
                    ProgressBar progressBar= findViewById(R.id.progressBar);


                    //calcolo percentuale
                    if(Integer.parseInt(readMessage)<=FULL){
                        b.setText("100%");
                        progressBar.setProgress(100);
                    }else if(Integer.parseInt(readMessage)>=EMPTY){
                        b.setText("0%");
                        progressBar.setProgress(0);
                    }else{
                        int max= EMPTY-FULL;
                        int val=EMPTY-Integer.parseInt(readMessage);
                        int percentuale=(val*100)/max;
                        b.setText(percentuale+"%");
                        progressBar.setProgress(percentuale);

                    }

                    break;
                case Costanti.MESSAGGIO_TOAST:
                    Toast.makeText(getApplicationContext(), msg.getData().getString(Costanti.TOAST), Toast.LENGTH_SHORT).show();
                    break;
            }
        }

    };




    class ChiamataDB extends AsyncTask<Integer, Void, String>{

        private  int flag;


        @Override
        protected void onPreExecute() {
        super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
        super.onPostExecute(s);
        if(s!=null) {
            if (flag == 0) {
                //Scriviamo sul DB
                if (!s.equals("ok")) {
                    //il salvataggio non é andato a buon fine lo salviamo nella internal storage
                    try {
                        File file= new File(getApplicationContext().getCacheDir(), "petsfood.txt");
                        FileOutputStream fos= new FileOutputStream(file);
                        fos.write(salvaDati().getBytes());
                        fos.close();
                    } catch (IOException e){

                    }
                }
            } else if (flag == 1) {
                //Leggiamo DB
                if (!s.equals("no")) {
                    lista = getDataList(s);
                }
            } else if (flag == 2) {
                if (s.equals("ok")) {
                    //Password sostituita correttamente
                    fragmentListBluetooth.setVisibility(View.INVISIBLE);
                    fragmentButton.setVisibility(View.INVISIBLE);
                    buttonEroga.setVisibility(View.VISIBLE);
                    fragmentListData.setVisibility(View.INVISIBLE);
                    textPercetuale.setVisibility(View.VISIBLE);
                    progressBar.setVisibility(View.VISIBLE);
                    fragmentModifcaPsw.setVisibility(View.INVISIBLE);
                    passwordUtente= passwordUtenteNew;
                    passwordUtenteNew=null;

                }else{
                    TextView textViewModifica= findViewById(R.id.textViewModifca);
                    textViewModifica.setText("Impossibile modificare la password");
                }

            }
        }
    }
        @Override
        protected String doInBackground(Integer... integers) {
            flag= integers[0];
        try{
            java.net.URL url=null ;
            HttpURLConnection connessione=null;
            Uri.Builder builder = null;
            if(flag==0) {

                //Aggiorniamo i dati nel DB

                url = new URL(URL2);
                connessione = (HttpURLConnection) url.openConnection();
                connessione.setRequestMethod("POST");
                connessione.setDoOutput(true);
                connessione.setDoInput(true);
                builder = new Uri.Builder()
                        .appendQueryParameter("id", idUtente)
                        .appendQueryParameter("list", salvaDati());

            }else if(flag==1) {
                //Recuperiamo i dati dal DB

                url = new URL(URL1);
                connessione = (HttpURLConnection) url.openConnection();
                connessione.setRequestMethod("POST");
                connessione.setDoOutput(true);
                connessione.setDoInput(true);
                builder = new Uri.Builder()
                        .appendQueryParameter("id", idUtente);

            }else if(flag==2){
                //Aggiorniamo la password modificata
                url = new URL(URL3);
                connessione = (HttpURLConnection) url.openConnection();
                connessione.setRequestMethod("POST");
                connessione.setDoOutput(true);
                connessione.setDoInput(true);
                builder = new Uri.Builder()
                        .appendQueryParameter("id", idUtente)
                        .appendQueryParameter("nuovaPsw",passwordUtente);

            }



            String query= builder.build().getEncodedQuery();
            OutputStream os= connessione.getOutputStream();
            BufferedWriter w = new BufferedWriter(
                    new OutputStreamWriter(os, "UTF-8"));
            w.write(query);
            w.flush();
            w.close();
            os.close();
            connessione.connect();
            BufferedReader br = new BufferedReader
                    (new InputStreamReader(connessione.getInputStream()));
            String risposta=br.readLine(); //leggiamo la risposta del server
            return risposta;
        } catch (Exception e) {
            return null;
        }
        }
    }

}