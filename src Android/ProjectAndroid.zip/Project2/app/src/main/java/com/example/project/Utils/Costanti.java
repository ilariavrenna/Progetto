package com.example.project.Utils;

public interface Costanti {

    int MESSAGGIO_TOAST=1;
    int MESSAGGIO_NUOVO_STATO=2;
    int MESSAGGIO_RICEVUTO=4;

    String TOAST= "TOAST";

}
