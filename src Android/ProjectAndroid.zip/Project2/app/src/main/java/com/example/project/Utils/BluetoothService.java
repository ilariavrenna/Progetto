package com.example.project.Utils;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class BluetoothService{

    private final BluetoothAdapter bluetoothAdapter;
    private final Handler handler;
    private int stato;
    private boolean connesso= false;

    private static final UUID SPP_UUID = java.util.UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    public static final int STATE_NONE = 0;
    public static final int STATE_CONNECTING = 1;
    public static final int STATE_CONNECTED = 2;

    private ConnectThread connectThread;
    private ConnectedThread connectedThread;


    public BluetoothService(BluetoothAdapter bluetoothAdapter, Handler handler) {
        this.bluetoothAdapter= bluetoothAdapter;
        stato=STATE_NONE;
        this.handler=handler;
    }




    public synchronized void stabilisciConnessione(BluetoothDevice device){

        if(connectThread!=null){
            connectThread.cancel();
            connectThread=null;
        }


        if(connectedThread!=null){
            connectedThread.cancel();
            connectedThread=null;
        }
        connectThread = new ConnectThread(device);
        stato=STATE_CONNECTING;
        aggiornaStatoConnessione();
        connectThread.start();
    }

    public synchronized void connesso(BluetoothSocket socket){

        if(connectedThread!=null){
            connectedThread.cancel();
            connectedThread= null;
        }

        connectedThread= new ConnectedThread(socket);
        connectedThread.start();


    }

    public void write(byte[] message){
        ConnectedThread r;
        synchronized (this) {
            if (stato != STATE_CONNECTED) return;
            r = connectedThread;
        }
        r.write(message);

    }




    public synchronized void stop(){

        if(connectedThread!=null){
            connectedThread.cancel();
            connectedThread=null;
        }

        if(stato!= STATE_CONNECTING){
            if(connectThread!=null) {
                connectThread.cancel();
                connectThread = null;
            }
        }
        stato=STATE_NONE;

        aggiornaStatoConnessione();
    }

    private void connessioneFallita(){

        stop();

        Message msg= handler.obtainMessage(Costanti.MESSAGGIO_TOAST);
        Bundle bundle= new Bundle();
        bundle.putString(Costanti.TOAST, "Impossibile connettersi al dispositivo remoto.");
        msg.setData(bundle);
        handler.sendMessage(msg);

    }

    private void connessionePersa(){

        stop();

    }

    private synchronized void aggiornaStatoConnessione(){
        stato= getStato();
        handler.obtainMessage(Costanti.MESSAGGIO_NUOVO_STATO, stato, -1).sendToTarget();
    }

    public synchronized int getStato(){
        return stato;
    }



    private class ConnectThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final BluetoothDevice mmDevice;

        public ConnectThread(BluetoothDevice device) {
            BluetoothSocket tmp = null;
            mmDevice = device;
            try {

                tmp= device.createRfcommSocketToServiceRecord(SPP_UUID);

            } catch (IOException e) {

            }
            mmSocket = tmp;

        }

        public void run() {
            bluetoothAdapter.cancelDiscovery();

            try {
                mmSocket.connect();
            } catch (IOException connectException) {

                try {
                    mmSocket.close();
                } catch (IOException closeException) {
                }
                //CONNESSIONE FALLITA (metodo: connectionFailed())
                connessioneFallita();
                return;
            }

            connesso(mmSocket);

        }

        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
            }
        }
    }




    private class ConnectedThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;
        private byte[] mmBuffer; // mmBuffer store for the stream

        public ConnectedThread(BluetoothSocket socket) {
            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            try {
                tmpIn = socket.getInputStream();
                tmpOut= socket.getOutputStream();
            } catch (IOException e) {
            }
            try {
                tmpOut = socket.getOutputStream();
            } catch (IOException e) {
            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
            stato =STATE_CONNECTED;
            aggiornaStatoConnessione();
        }

        public void run() {
            mmBuffer = new byte[1024];
            int numBytes; // numero byte restituiti da read
            String s="";
            while (stato == STATE_CONNECTED){
                try{
                    numBytes= mmInStream.read(mmBuffer);
                    int index=0;
                    while(numBytes>index) {
                        String readMessage = new String(mmBuffer, index, 1);
                        if (!readMessage.equals("-"))
                            s += readMessage;
                        else {
                            handler.obtainMessage(Costanti.MESSAGGIO_RICEVUTO, s).sendToTarget();
                            s = "";
                        }
                        index++;
                    }

                }catch (IOException e){
                    connessionePersa();
                    break;

                }
            }
        }

        public void write(byte[] bytes) {
            try {
                mmOutStream.write(bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void cancel() {
            try {
                mmSocket.close();

            } catch (IOException e) {
            }
        }
    }
}
