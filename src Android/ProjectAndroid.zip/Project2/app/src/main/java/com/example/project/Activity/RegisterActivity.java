package com.example.project.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.R;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {

    private static final String URL= "http://192.168.1.13/vsc_android/insert_user.php";
    private String nomeUtente, email, password, passwordConferma;
    private EditText nomeUtenteText,emailText, passwordText, passConfText;
    private Pattern pattern= Pattern.compile("[a-zA-Z0-9][a-zA-Z0-9_]+");
    private static final int LUNGHEZZA_PASS=6, RESULT_NULL=-2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //Recupero le view per gestire i vari eventi
        nomeUtenteText= findViewById(R.id.nomeUtente);
        emailText= findViewById(R.id.emailUtente);
        passwordText= findViewById(R.id.passwordUtente);
        passConfText= findViewById(R.id.passwordUtenteConferma);



        nomeUtenteText.setOnFocusChangeListener(new MyFocus(findViewById(R.id.textViewNome)));

        emailText.setOnFocusChangeListener(new MyFocus(findViewById(R.id.textViewEmail)));

        passwordText.setOnFocusChangeListener(new MyFocus(findViewById(R.id.textViewPasswordCorta)));

        passConfText.setOnFocusChangeListener(new MyFocus(findViewById(R.id.textViewPassword)));


        Button buttonRegistrazione= findViewById(R.id.buttonRegistrazione);
        buttonRegistrazione.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Recuperiamo i dati inseriti nei vari campi
                nomeUtente = nomeUtenteText.getText().toString();
                email = emailText.getText().toString();
                password = passwordText.getText().toString();
                passwordConferma = passConfText.getText().toString();


                if (nomeUtente.equals("") && email.equals("") && password.equals("") && passwordConferma.equals("")) {
                    //Completare tutti i campi
                    TextView text = findViewById(R.id.textViewError);
                    text.setVisibility(View.VISIBLE);

                } else if (nomeUtente.equals("") || !verificaNomeUtente()) {
                    TextView t = findViewById(R.id.textViewNome);
                    t.setVisibility(View.VISIBLE);
                } else if (email.equals("") || !verificaEmail()) {
                    TextView t = findViewById(R.id.textViewEmail);
                    t.setVisibility(View.VISIBLE);

                } else if (password.equals("")) {

                    TextView t= findViewById(R.id.textViewPasswordCorta);
                    t.setText("Completare il campo password");
                    t.setVisibility(View.VISIBLE);

                 }else if(!verificaLunghezzaPassword()){
                    TextView t= findViewById(R.id.textViewPasswordCorta);
                    t.setText(R.string.passwordNonValida);
                    t.setVisibility(View.VISIBLE);

                } else if(passwordConferma.equals("")|| !verifcaPassword()){
                    TextView t= findViewById(R.id.textViewPassword);
                    t.setVisibility(View.VISIBLE);

                }else{
                    //Salvo nel DB
                    InserisciDati inseriscidati=new InserisciDati();
                    inseriscidati.execute();

                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onBackPressed() {
        //Quando l'utente preme il tasto back restituiamo result_null
        setResult(RESULT_NULL);
        super.onBackPressed();
    }

    private boolean verificaNomeUtente(){
        String nome_utente= nomeUtenteText.getText().toString();
        Matcher matcher= pattern.matcher(nome_utente);
        if(!matcher.matches()){
            return false;
        }
        return true;
    }

    private boolean verificaEmail(){
        String email= emailText.getText().toString();
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            return false;
        }
        return true;
    }

    private boolean verifcaPassword(){
        String psw= passwordText.getText().toString();
        String pswC= passConfText.getText().toString();

        if(!psw.equals(pswC)){
            return false;
        }
        return true;
    }

    private boolean verificaLunghezzaPassword(){
        String psw= passwordText.getText().toString();
        if( psw.length()<LUNGHEZZA_PASS){
            return false;
        }
        return true;
    }

    class InserisciDati extends AsyncTask<Void, Void, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null && s.equals("ok")){
                setResult(RESULT_OK);
            }
            else
            {
                setResult(RESULT_CANCELED);

            }
            finish();
        }
        @Override
        protected String doInBackground(Void... voids) { try {
            java.net.URL url=new URL(URL);
            HttpURLConnection connessione = (HttpURLConnection) url.openConnection();
            connessione.setRequestMethod("POST");
            connessione.setDoInput(true);
            connessione.setDoOutput(true);

            Uri.Builder builder = new Uri.Builder()
                    .appendQueryParameter("nome", nomeUtente )
                    .appendQueryParameter("email", email )
                    .appendQueryParameter("password", password )
                    .appendQueryParameter("lista", "null" ) ;
            String query = builder.build().getEncodedQuery();
            // Apriamo la connessione per inviare i dati
            OutputStream os= null;
            try {
                os = connessione.getOutputStream();
            }catch (Exception e){
                System.out.println(e);
            }
            BufferedWriter w = new BufferedWriter(
                    new OutputStreamWriter(os, "UTF-8"));
            w.write(query);
            w.flush();
            w.close();
            os.close();
            connessione.connect();
            BufferedReader br = new BufferedReader
                    (new InputStreamReader(connessione.getInputStream()));
            String risposta=br.readLine(); //leggiamo la risposta del server
            return risposta;
        } catch (Exception e) {
            return null;
        }
        }
    }

    private class MyFocus implements View.OnFocusChangeListener{

        TextView textView;

        public MyFocus(View view){
            textView= (TextView) view;
        }

        @Override
        public void onFocusChange(View view, boolean b) {
            EditText t= (EditText) view;
            if(!b && !t.getText().toString().equals("")){
                switch (view.getId()){
                    case R.id.nomeUtente:
                        if(!verificaNomeUtente()){
                            textView.setVisibility(View.VISIBLE);
                        }
                        break;
                    case R.id.emailUtente:
                        if(!verificaEmail()){
                            textView.setVisibility(View.VISIBLE);
                        }
                        break;
                    case R.id.passwordUtenteConferma:
                        if(!verifcaPassword()){
                            textView.setVisibility(View.VISIBLE);
                        }
                        break;
                    case R.id.passwordUtente:
                        if(!verificaLunghezzaPassword()){
                            textView.setText(R.string.passwordNonValida);
                            textView.setVisibility(View.VISIBLE);
                        }
                        break;
                }
            }else if(b && textView.getVisibility()==View.VISIBLE ){
                textView.setVisibility(View.INVISIBLE);
            }
        }
    }


}